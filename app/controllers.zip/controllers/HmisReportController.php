<?php
set_time_limit(0); //60 seconds = 1 minute
class HmisReportController extends \BaseController {
	public function hmis105($month = '')
	{
		$month = ($month == '') ? date('Y-m') : $month ;
		$testTypes = TestType::all();
		
		$visits = $this->getVisistsByMonth($month);
		$sepecimen_counts = $this->getSpecimenTotals($month);
		$total_test_count = $this->getHematologyCounts($month);
		$serology_test_counts = $this->getSerologyCounts($month);
		$microbiology_test_counts = $this->getMicrobiologyCounts($month);
		$parasitology_test_counts = $this->getParasitologyCounts($month);
		$stoolmicroscopy_test_counts = $this->getStoolmicroscopyCounts($month);
		$chemistry_test_counts = $this->getChemistryCounts($month);
		$blood_transfussion_test_counts  = $this->getBloodTransfusionCounts($month);
		$culture_and_sensitivity_counts  = $this->getCultureAndSensitivityCounts($month);
		$immunology_counts = $this->getImmunologyCounts($month);
		$molecular_counts = $this->getMolecularCounts($month);
		$hiv_by_purpose = $this->getHivTestByPurpose($month);
		$referral_tests = $this->getReferredTestCounts($month);
		$referred_microbiology = $this->getReferredMicrobiologyCounts($month);
		$referred_virology = $this->getReferredVirologyCounts($month);
		$referred_parasitology = $this->getReferredParasitologyCounts($month);
		$equipment_breakdown = $this->getEquipmentBreakdownCounts($month);
		$reagent_stockout = $this->getReagentStockoutCounts($month);
		$supplies_stockout = $this->getSuppliesStockoutCounts($month);
		$power_outage = $this->getPowerOutageCounts($month);
		$no_testing_expertise = $this->getTestingExpertiseCounts($month);
		$required_equipment = $this->getRequiredEquipmentCounts($month);
		$confirmatory_testing = $this->getConfirmatoryTestingCounts($month);
		$qa_retesting = $this->getQaRetestingCounts($month);
		$other_referral_reasons = $this->getOtherReferralReasonsCounts($month);
		$KlebsiellaOrganism = $this->getKlebsiellaOrganismCounts($month);
		$EscherichiaOrganism = $this->getEscherichiaOrganismCounts($month);
		$salmonellaOrganism = $this->getsalmonellaOrganismCounts($month);
		$ShigellaOrganism = $this->getShigellaOrganismCounts($month);
		$NeisseriaOrganism = $this->getNeisseriaOrganismCounts($month);
		$StaphylococcusOrganism = $this->getStaphylococcusOrganismCounts($month);
		$StreptococcusOrganism = $this->getStreptococcusOrganismCounts($month);
		$AcinetobacterOrganism = $this->getAcinetobacterOrganismCounts($month);
		$VibrioOrganism = $this->getVibrioOrganismCounts($month);
		$EnterococcusOrganism = $this->getEnterococcusOrganismCounts($month);
		$HaemophilusOrganism = $this->getHaemophilusOrganismCounts($month);
		$NeisseriamOrganism = $this->getNeisseriamOrganismCounts($month);
		$CampylobacterOrganism = $this->getCampylobacterOrganismCounts($month);
		$OthersOrganism = $this->getOthersOrganismCounts($month);
		$blood_specimen_rejection = $this->getBloodSpecimenRejectionCounts($month);
		$stool_specimen_rejection = $this->getStoolSpecimenRejectionCounts($month);
		$urine_specimen_rejection = $this->getUrineSpecimenRejectionCounts($month);
		$sputum_specimen_rejection = $this->getSputumSpecimenRejectionCounts($month);
		$pus_specimen_rejection = $this->getPusSpecimenRejectionCounts($month);
		$genital_specimen_rejection = $this->getGenitalSpecimenRejectionCounts($month);
		$skin_specimen_rejection = $this->getSkinSpecimenRejectionCounts($month);
		$other_specimen_rejection = $this->getOtherSpecimenRejectionCounts($month);
		$isolates = $this->getIsolateCounts($month);
		return View::make('reports.hmis.hmis05')
							->with('month', $month)
							->with('isolates', $isolates)
							->with('sepecimen_counts', $sepecimen_counts)
							->with('KlebsiellaOrganism', $KlebsiellaOrganism)
							->with('EscherichiaOrganism', $EscherichiaOrganism)
							->with('salmonellaOrganism', $salmonellaOrganism)
							->with('ShigellaOrganism', $ShigellaOrganism)
							->with('NeisseriaOrganism', $NeisseriaOrganism)
							->with('StaphylococcusOrganism', $StaphylococcusOrganism)
							->with('StreptococcusOrganism', $StreptococcusOrganism)
							->with('AcinetobacterOrganism', $AcinetobacterOrganism)
							->with('VibrioOrganism', $VibrioOrganism)
							->with('EnterococcusOrganism', $EnterococcusOrganism)
							->with('HaemophilusOrganism', $HaemophilusOrganism)
							->with('NeisseriamOrganism', $NeisseriamOrganism)
							->with('CampylobacterOrganism', $CampylobacterOrganism)
							->with('OthersOrganism', $OthersOrganism)
							->with('blood_specimen_rejection', $blood_specimen_rejection)
							->with('stool_specimen_rejection', $stool_specimen_rejection)
							->with('urine_specimen_rejection', $urine_specimen_rejection)
							->with('sputum_specimen_rejection', $sputum_specimen_rejection)
							->with('pus_specimen_rejection', $pus_specimen_rejection)
							->with('genital_specimen_rejection', $genital_specimen_rejection)
							->with('skin_specimen_rejection', $skin_specimen_rejection)
							->with('other_specimen_rejection', $other_specimen_rejection)
							->with('equipment_breakdown', $equipment_breakdown)
							->with('other_referral_reasons', $other_referral_reasons)
							->with('qa_retesting', $qa_retesting)
							->with('confirmatory_testing', $confirmatory_testing)
							->with('required_equipment', $required_equipment)
							->with('no_testing_expertise', $no_testing_expertise)
							->with('power_outage', $power_outage)
							->with('supplies_stockout', $supplies_stockout)
							->with('reagent_stockout', $reagent_stockout)
							->with('total_test_count', $total_test_count)
							->with('serology_test_counts', $serology_test_counts)
							->with('parasitology_test_counts', $parasitology_test_counts)
							->with('stoolmicroscopy_test_counts', $stoolmicroscopy_test_counts)
							->with('chemistry_test_counts', $chemistry_test_counts)
							->with('microbiology_test_counts', $microbiology_test_counts)
							->with('visits', $visits)
							->with('blood_transfussion_test_counts', $blood_transfussion_test_counts)
							->with('culture_and_sensitivity_counts',$culture_and_sensitivity_counts)
							->with('immunology_counts', $immunology_counts)
							->with('molecular_counts',$molecular_counts)
							->with('referral_tests',$referral_tests)
							->with('referred_microbiology',$referred_microbiology)
							->with('referred_virology',$referred_virology)
							->with('referred_parasitology',$referred_parasitology)
							->with('hiv_by_purpose',$hiv_by_purpose);
	}

	/*
	* @parameters - $month - the period of consideration
	* Uses mysql query to get the counts of specimen collected out and those collected in 
	* @Return - array of total counts for the period for specimen of interest
	*/
	private function getVisistsByMonth($month){
		$visits_counts = ['in_patients' => 0, 'out_patients' => 0];
		$query = "SELECT SUM(IF(`visit_type` LIKE '%In-patient%', 1, 0)) AS 'in_patients',SUM(IF(`visit_type` LIKE '%Out-patient%', 1, 0)) AS 'out_patients'
				FROM `unhls_visits`
				WHERE `created_at` LIKE '%".$month."%' ";
		$results = \DB::select($query);
		if(!empty($results[0]->out_patients)){
			$visits_counts['in_patients'] = $results[0]->in_patients;
			$visits_counts['out_patients'] = $results[0]->out_patients;
		}
		return  $visits_counts;
	}

	/*
	* @parameters - $month - the period of consideration
	* Uses mysql query to get the counts of specimen collected out and those collected in 
	* @Return - array of total counts for the period for specimen of interest
	*/
	private function getSpecimenTotals($month){
		$query = "select t.specimen_id, st.name, v.visit_type, st.id, v.id as visit_id from unhls_tests as t
INNER JOIN  unhls_visits v ON(v.id = t.visit_id)
INNER JOIN specimens s ON(t.specimen_id = s.id)
INNER JOIN specimen_types st ON(s.specimen_type_id = st.id)
WHERE `v`.`created_at` LIKE '%".$month."%' 
GROUP BY t.specimen_id";
	 $samples_on_visit = DB::select($query);
	 //define varialbe to hold the various counts
	 $blood_collected_in = 0; $blood_collected_out = 0;
	 $stool_collected_in = 0; $stool_collected_out = 0;
	 $urine_collected_in = 0; $urine_collected_out = 0;
	 $sputum_collected_in = 0; $sputum_collected_out = 0;
	 $csf_collected_in = 0; $csf_collected_out = 0;
	 $csf_collected_in = 0; $csf_collected_out = 0;
	 $biopsy_collected_in = 0; $biopsy_collected_out = 0;
	 $pus_swab_collected_in = 0; $pus_swab_collected_out = 0;
	 $genital_swab_collected_in = 0; $genital_swab_collected_out = 0;
	 $skin_collected_in = 0; $skin_collected_out = 0;
	 $others_collected_in = 0; $others_collected_out = 0;
	 $specimen_of_interest = array(23,13,20,24,27,14,17,16,11,7);
	 foreach ($samples_on_visit as $sample_on_visit){
	 	//samples in = out-patient + in-patients visit_types
	 	//the id is the specimen_type
	 	if(in_array($sample_on_visit->id, $specimen_of_interest)){
		 	if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 23){
		 		$blood_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 23){
		 		$blood_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 13){
		 		$stool_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 13){
		 		$stool_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 20){
		 		$urine_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 20){
		 		$urine_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 24){
		 		$sputum_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 24){
		 		$sputum_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 14){
		 		$csf_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 14){
		 		$csf_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 27){
		 		$biopsy_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 27){
		 		$biopsy_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 16){
		 		$pus_swab_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 16){
		 		$pus_swab_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 11){
		 		$genital_swab_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 11){
		 		$genital_swab_collected_out++;
		 	}else if(($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient') && $sample_on_visit->id == 7){
		 		$skin_collected_in++;
		 	}else if($sample_on_visit->visit_type == 'Referral' && $sample_on_visit->id == 7){
		 		$skin_collected_out++;
		 	}
		 }else{
		 	if($sample_on_visit->visit_type == 'Out-patient' || $sample_on_visit->visit_type == 'In-patient'){
		 		$others_collected_in++;
		 	}else{
		 		$others_collected_out++;
		 	}
		 }
	 }
	 $sample_counts_array = ['blood_collected_in' => $blood_collected_in,
	 					   'blood_collected_out' => $blood_collected_out,
	 					   'stool_collected_in' => $stool_collected_in,
	 					   'stool_collected_out' => $stool_collected_out,
	 					   'urine_collected_in' => $urine_collected_in,
	 					   'urine_collected_out' => $urine_collected_out,
	 					   'sputum_collected_in' => $sputum_collected_in,
	 					   'sputum_collected_out' => $sputum_collected_out,
	 					   'csf_collected_in' => $csf_collected_in,
	 					   'csf_collected_out' => $csf_collected_out,
	 					   'biopsy_collected_in' => $biopsy_collected_in,
	 					   'biopsy_collected_out' => $biopsy_collected_out,
	 					   'pus_swab_collected_in' => $pus_swab_collected_in,
	 					   'pus_swab_collected_out' => $pus_swab_collected_out,
	 					   'genital_swab_collected_in' => $genital_swab_collected_in,
	 					   'genital_swab_collected_out' => $genital_swab_collected_out,
	 					   'skin_collected_in' => $skin_collected_in,
	 					   'skin_collected_out' => $skin_collected_out,
	 					   'others_collected_in' => $others_collected_in,
	 					   'others_collected_out' => $others_collected_out,
						];
	//dd($sample_counts_array);
	return $sample_counts_array;
	}
	private function getTestCountsByLabSection($lab_section_id, $month){
		$query = "select test_type_id, tt.test_category_id as lab_section, count(ut.id) as total, count(utr.id) as Positive FROM unhls_tests ut 
		INNER JOIN test_types tt ON(ut.test_type_id = tt.id)
		INNER JOIN test_categories tc ON(tc.id = tt.test_category_id AND tt.test_category_id = $lab_section_id)
		INNER JOIN unhls_test_results utr ON(utr.test_id = ut.id)
		WHERE `ut`.`time_created` LIKE '%".$month."%'
		GROUP BY test_type_id";
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	return $rows;
	}

	private function getReferralTestCountsByLabSection($lab_section_id, $month){
		$query = "select ut.test_type_id, rr.created_at, tt.test_category_id as lab_section, count(rr.id) as total FROM referrals rr 
		LEFT JOIN unhls_test_results utr ON(rr.test_id = utr.test_id)
		INNER JOIN unhls_tests ut ON(rr.id = ut.id)
		INNER JOIN test_types tt ON(ut.test_type_id = tt.id)
		INNER JOIN test_categories tc ON(tc.id = tt.test_category_id AND tt.test_category_id = $lab_section_id)
		WHERE `ut`.`time_created` LIKE '%".$month."%'
		GROUP BY test_type_id";
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
		
		
	 	$rows = DB::select($query);
	 	return $rows;
	}

	private function getReferralTestCountsByReasons($lab_section_id, $month){
		$query = "select ut.test_type_id, count(rr.id) as total FROM referrals rr 
		INNER JOIN referral_reasons rrs ON(rr.referral_reason = rrs.id AND rr.referral_reason = $lab_section_id)
		INNER JOIN unhls_tests ut ON(rr.test_id = ut.id)
		INNER JOIN test_types tt ON(ut.test_type_id = tt.id)
		WHERE `rr`.`sample_date` LIKE '%".$month."%'
		GROUP BY test_type_id";
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	return $rows;
	}

	private function getAMRservillence($lab_section_id, $month){
		$query = "select rr.drug_id, rr.drug_susceptibility_measure_id as lab_section, count(rr.id) as total FROM drug_susceptibility rr 
		INNER JOIN drugs ut ON(rr.drug_id = ut.id)
		INNER JOIN isolated_organisms tt ON(rr.isolated_organism_id = tt.id)
		INNER JOIN organisms org ON(tt.organism_id = org.id AND tt.organism_id = $lab_section_id)
		INNER JOIN drug_susceptibility_measures dsm ON(rr.drug_susceptibility_measure_id = dsm.id)
		WHERE `rr`.`created_at` LIKE '%".$month."%'
		GROUP BY rr.drug_id";
		
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	return $rows;
	}

	private function getSpecimenRejectionTotalBySampleType($lab_section_id, $month){
		$query = "select reason_id, count(srr.id) as total FROM analytic_specimen_rejection_reasons srr 
		INNER JOIN rejection_reasons rr ON(srr.reason_id = rr.id)
		INNER JOIN specimens ss ON(srr.specimen_id = ss.id)
		INNER JOIN specimen_types st ON(ss.specimen_type_id = st.id AND ss.specimen_type_id = $lab_section_id)
		WHERE `srr`.`created_at` LIKE '%".$month."%' 
		GROUP BY reason_id";
		
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	return $rows;
	}

	private function getTotalNumberOfIsolates($lab_section_id, $month){
		$query = "select org.id as organism, count(org.id) as total FROM drug_susceptibility rr 
		INNER JOIN drugs ut ON(rr.drug_id = ut.id)
		INNER JOIN isolated_organisms tt ON(rr.isolated_organism_id = tt.id)
		INNER JOIN organisms org ON(tt.organism_id = org.id AND tt.organism_id = $lab_section_id)
		INNER JOIN drug_susceptibility_measures dsm ON(rr.drug_susceptibility_measure_id = dsm.id)
		WHERE `rr`.`created_at` LIKE '%".$month."%'
		GROUP BY org.id";
		
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	return $rows;
	}

	private function getIsolateCounts($month){
		$test_type_ids = $this->getTestTypeIDs('isolate');
		$rows = $this->getTotalNumberOfIsolates($test_type_ids['organism'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['Klebsiella_pneumoniae'] = 0;
		$test_type_counts['Escherichia_coli'] = 0;
		$test_type_counts['Salmonella_spp'] = 0;
		$test_type_counts['Shigella_spp'] = 0;
		$test_type_counts['Neisseria_gonorrhoeae'] = 0;
		$test_type_counts['Staphylococcus_aureus'] = 0;
		// $test_type_counts['shigella_dysentery'] = 0;
		$test_type_counts['Streptococcus_pneumoniae'] = 0;
		$test_type_counts['Acinetobacter_baumannii'] = 0;
		$test_type_counts['Vibrio_cholerae'] = 0;
		$test_type_counts['Enterococcus_spp'] = 0;
		$test_type_counts['Haemophilus_influenzae'] = 0;
		$test_type_counts['Neisseria_meningitides'] = 0;
		$test_type_counts['Campylobacter'] = 0;
		$test_type_counts['others'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['Klebsiella_pneumoniae']){
	 			$test_type_counts['Klebsiella_pneumoniae'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Escherichia_coli']){
	 			$test_type_counts['Escherichia_coli'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Salmonella_spp']){
	 			$test_type_counts['Salmonella_spp'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Shigella_spp']){
	 			$test_type_counts['Shigella_spp'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Neisseria_gonorrhoeae']){
	 			$test_type_counts['Neisseria_gonorrhoeae'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Staphylococcus_aureus']){
	 			$test_type_counts['Staphylococcus_aureus'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Streptococcus_pneumoniae']){
	 			$test_type_counts['Streptococcus_pneumoniae'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Acinetobacter_baumannii']){
	 			$test_type_counts['Acinetobacter_baumannii'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Vibrio_cholerae']){
	 			$test_type_counts['Vibrio_cholerae'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Enterococcus_spp']){
	 			$test_type_counts['Enterococcus_spp'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haemophilus_influenzae']){
	 			$test_type_counts['Haemophilus_influenzae'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Neisseria_meningitides']){
	 			$test_type_counts['Neisseria_meningitides'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Campylobacter']){
	 			$test_type_counts['Campylobacter'] = $row->total;
	 		}else{
	 			$test_type_counts['others'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getHematologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('hematology');
		$rows = $this->getTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['hb_non_automated'] = 0;
		$test_type_counts['vdrl_rrr'] = 0;
		$test_type_counts['cbc'] = 0;
		$test_type_counts['film_comment'] = 0;
		$test_type_counts['tpha'] = 0;
		$test_type_counts['esr'] = 0;
		$test_type_counts['shigella_dysentery'] = 0;
		$test_type_counts['bleeding_time'] = 0;
		$test_type_counts['Hepatitisb_sags'] = 0;
		$test_type_counts['prothrombin_time'] = 0;
		$test_type_counts['brucella'] = 0;
		$test_type_counts['clotting_time'] = 0;
		$test_type_counts['pregnancy_test'] = 0;
		$test_type_counts['sickle_cell'] = 0;
		$test_type_counts['others'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['hb_non_automated']){
	 			$test_type_counts['hb_non_automated'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['vdrl_rrr']){
	 			$test_type_counts['vdrl_rrr'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['cbc']){
	 			$test_type_counts['cbc'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['film_comment']){
	 			$test_type_counts['film_comment'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['tpha']){
	 			$test_type_counts['tpha'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['esr']){
	 			$test_type_counts['esr'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['bleeding_time']){
	 			$test_type_counts['bleeding_time'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Hepatitisb_sags']){
	 			$test_type_counts['Hepatitisb_sags'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['prothrombin_time']){
	 			$test_type_counts['prothrombin_time'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['brucella']){
	 			$test_type_counts['brucella'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['clotting_time']){
	 			$test_type_counts['clotting_time'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['pregnancy_test']){
	 			$test_type_counts['pregnancy_test'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['sickle_cell']){
	 			$test_type_counts['sickle_cell'] = $row->total;
	 		}else{
	 			$test_type_counts['others'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}
	private function getSerologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('serology');
		$rows = $this->getTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['vdrl_rrr'] = 0;
		$test_type_counts['tpha'] = 0;
		$test_type_counts['shigella_dysentery'] = 0;
		$test_type_counts['hepatitisb_sags'] = 0;
		$test_type_counts['brucella'] = 0;
		$test_type_counts['pregnancy_test'] = 0;
		$test_type_counts['crag'] = 0;
		$test_type_counts['rheumatoid_factor'] = 0;
		$test_type_counts['hepb_core_ag'] = 0;
		$test_type_counts['Hepatitisb_sags'] = 0;
		$test_type_counts['hepa'] = 0;
		$test_type_counts['hepc'] = 0;

	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['vdrl_rrr']){
	 			$test_type_counts['vdrl_rrr'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['tpha']){
	 			$test_type_counts['tpha'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hepatitisb_sags']){
	 			$test_type_counts['hepatitisb_sags'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['brucella']){
	 			$test_type_counts['brucella'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['pregnancy_test']){
	 			$test_type_counts['pregnancy_test'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['crag']){
	 			$test_type_counts['crag'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['shigella_dysentery']){
	 			$test_type_counts['shigella_dysentery'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['rheumatoid_factor']){
	 			$test_type_counts['rheumatoid_factor'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hepb_core_ag']){
	 			$test_type_counts['hepb_core_ag'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Hepatitisb_sags']){
	 			$test_type_counts['Hepatitisb_sags'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hepa']){
	 			$test_type_counts['hepa'] = $row->total;
	 		}else{
	 			$test_type_counts['hepc'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getMicrobiologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('microbiology');
		$rows = $this->getTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['auramine_fm'] = 0;
		$test_type_counts['zn_for_afb'] = 0;
		$test_type_counts['leishman_stain'] = 0;
		$test_type_counts['gram'] = 0;
		$test_type_counts['india_ink'] = 0;
		$test_type_counts['urine_microscopy'] = 0;
		$test_type_counts['wet_prep'] = 0;
		$test_type_counts['others'] = 0;

	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['auramine_fm']){
	 			$test_type_counts['auramine_fm'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['zn_for_afb']){
	 			$test_type_counts['zn_for_afb'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['gram']){
	 			$test_type_counts['gram'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['india_ink']){
	 			$test_type_counts['india_ink'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['urine_microscopy']){
	 			$test_type_counts['urine_microscopy'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['wet_prep']){
	 			$test_type_counts['wet_prep'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['leishman_stain']){
	 			$test_type_counts['leishman_stain'] = $row->total;
	 		}else{
	 			$test_type_counts['others'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getParasitologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('parasitology');
		$rows = $this->getTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['malaria_microscopy'] = 0;
		$test_type_counts['malaria_rdts'] = 0;
		$test_type_counts['trypasonoma'] = 0;
		$test_type_counts['micro_filaria'] = 0;
		$test_type_counts['leishmania'] = 0;
		$test_type_counts['trichinella'] = 0;
		$test_type_counts['borrellia'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['malaria_microscopy']){
	 			$test_type_counts['malaria_microscopy'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['malaria_rdts']){
	 			$test_type_counts['malaria_rdts'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['micro_filaria']){
	 			$test_type_counts['micro_filaria'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['leishmania']){
	 			$test_type_counts['leishmania'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['trichinella']){
	 			$test_type_counts['trichinella'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['borrellia']){
	 			$test_type_counts['borrellia'] = $row->total;
	 		}else{
	 			$test_type_counts['trypasonoma'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getStoolmicroscopyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('stoolmicroscopy');
		$rows = $this->getTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['entamoeba'] = 0;
		$test_type_counts['giardia'] = 0;
		$test_type_counts['cryptosporidium'] = 0;
		$test_type_counts['isospora'] = 0;
		$test_type_counts['cyclospora'] = 0;
		$test_type_counts['strongyloides'] = 0;
		$test_type_counts['shistosoma'] = 0;
		$test_type_counts['taenia'] = 0;
		$test_type_counts['askaris'] = 0;
		$test_type_counts['hookworm'] = 0;
		$test_type_counts['trichuris'] = 0;
		$test_type_counts['other_parasites'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['entamoeba']){
	 			$test_type_counts['entamoeba'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['giardia']){
	 			$test_type_counts['giardia'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['cryptosporidium']){
	 			$test_type_counts['cryptosporidium'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['isospora']){
	 			$test_type_counts['isospora'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['cyclospora']){
	 			$test_type_counts['cyclospora'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['strongyloides']){
	 			$test_type_counts['strongyloides'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['shistosoma']){
	 			$test_type_counts['shistosoma'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['taenia']){
	 			$test_type_counts['taenia'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['askaris']){
	 			$test_type_counts['askaris'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hookworm']){
	 			$test_type_counts['hookworm'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['trichuris']){
	 			$test_type_counts['trichuris'] = $row->total;
	 		}else{
	 			$test_type_counts['other_parasites'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getChemistryCounts($month){
		$test_type_ids = $this->getTestTypeIDs('chemistry');
		$rows = $this->getTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['urea'] = 0;
		$test_type_counts['calcium'] = 0;
		$test_type_counts['potassium'] = 0;
		$test_type_counts['sodium'] = 0;
		$test_type_counts['creatinine'] = 0;
		$test_type_counts['alt'] = 0;
		$test_type_counts['ast'] = 0;
		$test_type_counts['albumin'] = 0;
		$test_type_counts['total_protein'] = 0;
		$test_type_counts['triglycerides'] = 0;
		$test_type_counts['cholesterol'] = 0;
		$test_type_counts['free_t3'] = 0;
		$test_type_counts['free_t4'] = 0;
		$test_type_counts['tsh'] = 0;
		$test_type_counts['alkaline_phosphate'] = 0;
		$test_type_counts['amylase'] = 0;
		$test_type_counts['glucose'] = 0;
		$test_type_counts['total_bilirubin'] = 0;
		$test_type_counts['lipase'] = 0;
		$test_type_counts['afp'] = 0;
		$test_type_counts['others'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['urea']){
	 			$test_type_counts['urea'] =$row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['calcium']){
	 			$test_type_counts['calcium'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['potassium']){
	 			$test_type_counts['potassium'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['sodium']){
	 			$test_type_counts['sodium'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['creatinine']){
	 			$test_type_counts['creatinine'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['alt']){
	 			$test_type_counts['alt'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['ast']){
	 			$test_type_counts['ast'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['albumin']){
	 			$test_type_counts['albumin'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['total_protein']){
	 			$test_type_counts['total_protein'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['triglycerides']){
	 			$test_type_counts['triglycerides'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['cholesterol']){
	 			$test_type_counts['cholesterol'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['free_t3']){
	 			$test_type_counts['free_t3'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['free_t4']){
	 			$test_type_counts['free_t4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['tsh']){
	 			$test_type_counts['tsh'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['alkaline_phosphate']){
	 			$test_type_counts['alkaline_phosphate'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['amylase']){
	 			$test_type_counts['amylase'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['glucose']){
	 			$test_type_counts['glucose'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['total_bilirubin']){
	 			$test_type_counts['total_bilirubin'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['lipase']){
	 			$test_type_counts['lipase'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['afp']){
	 			$test_type_counts['afp'] = $row->total;
	 		}else{
	 			$test_type_counts['others'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}
	
	private function getBloodTransfusionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('blood_transfusion');
		$rows = $this->getTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		$test_type_counts = $this->getTestTypeInitialCounts('blood_transfusion');
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['ahb_combs_test']){
	 			$test_type_counts['ahb_combs_test'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['abo_grouping']){
	 			$test_type_counts['abo_grouping'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['cross_matching']){
	 			$test_type_counts['cross_matching'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}
	private function getCultureAndSensitivityCounts($month){
		$test_type_ids = $this->getTestTypeIDs('culture_and_sensitivity_specimen');
		$test_type_counts = $this->getTestTypeInitialCounts('culture_and_sensitivity_specimen');
		$query = "SELECT specimen_id, test_status_id FROM unhls_tests WHERE specimen_id = ".$test_type_ids['test_type_id']." AND time_created LIKE '%".$month."%'";
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->specimen_id = $test_type_ids['blood']){
	 			$test_type_counts['blood'] = $row->total;
	 		}else if((int)$row->specimen_id = $test_type_ids['urine']){
	 			$test_type_counts['urine'] = $test_type_counts['urine'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['stool']){
	 			$test_type_counts['stool'] = $test_type_counts['stool'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['sputum']){
	 			$test_type_counts['sputum'] = $test_type_counts['sputum'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['nosal_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['rectal_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['wound_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['pus_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['eye_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['ear_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['throat_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}else if((int)$row->specimen_id = $test_type_ids['uretheral_swab']){
	 			$test_type_counts['swabs'] = $test_type_counts['swabs'] + 1;
	 		}

	 	}
	 	return $test_type_counts;
	}
	private function getImmunologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('immunology');
		$test_type_counts = $this->getTestTypeInitialCounts('immunology');
		$query = "SELECT test_type_id, test_status_id FROM unhls_tests WHERE test_type_id IN(".$test_type_ids['cd4'].",".$test_type_ids['hiv_viral_load'].",".$test_type_ids['hepb'].") AND time_created LIKE '%".$month."%'";
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['cd4']){
	 			$test_type_counts['cd4'] = $test_type_counts['cd4'] + 1;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv_viral_load']){
	 			$test_type_counts['hiv_viral_load'] = $test_type_counts['hiv_viral_load'] + 1;
	 		}else if((int)$row->test_type_id == $test_type_ids['hepb']){
	 			$test_type_counts['hepb'] = $test_type_counts['hepb'] + 1;
	 		}
	 	}
	 	return $test_type_counts;
	}
	private function getMolecularCounts($month){
		$test_type_ids = $this->getTestTypeIDs('molecular');
		$test_type_counts = $this->getTestTypeInitialCounts('molecular');
		$query = "SELECT test_type_id, test_status_id FROM unhls_tests WHERE test_type_id IN(".$test_type_ids['tb_genexpert'].",".$test_type_ids['latent_tb'].",".$test_type_ids['tb_lam'].") AND time_created LIKE '%".$month."%'";
		//set variables for the target tests -from 
		//also get array of test_type ids to use in condition
	 	$rows = DB::select($query);
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['tb_genexpert']){
	 			$test_type_counts['tb_genexpert'] = $test_type_counts['tb_genexpert'] + 1;
	 		}else if((int)$row->test_type_id == $test_type_ids['latent_tb']){
	 			$test_type_counts['latent_tb'] = $test_type_counts['latent_tb'] + 1;
	 		}else if((int)$row->test_type_id == $test_type_ids['tb_lam']){
	 			$test_type_counts['tb_lam'] = $test_type_counts['tb_lam'] + 1;
	 		}
	 	}
	 	return $test_type_counts;
	}

	private function getReferredTestCounts($month){
		$test_type_ids = $this->getTestTypeIDs('referralTests');
		$rows = $this->getReferralTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['eid'] = 0;
		$test_type_counts['hiv_viral_load'] = 0;
		$test_type_counts['cd4'] = 0;
		$test_type_counts['sickle_cell_confirmation'] = 0;
		$test_type_counts['histology'] = 0;
		$test_type_counts['polio'] = 0;
		$test_type_counts['sars'] = 0;
		$test_type_counts['tb_genexpert'] = 0;
		$test_type_counts['mdr_tb'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['eid']){
	 			$test_type_counts['eid'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv_viral_load']){
	 			$test_type_counts['hiv_viral_load'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['cd4']){
	 			$test_type_counts['cd4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['sickle_cell_confirmation']){
	 			$test_type_counts['sickle_cell_confirmation'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['histology']){
	 			$test_type_counts['histology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['polio']){
	 			$test_type_counts['polio'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['sars']){
	 			$test_type_counts['sars'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['tb_genexpert']){
	 			$test_type_counts['tb_genexpert'] = $row->total;
	 		}else{
	 			$test_type_counts['mdr_tb'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getReferredMicrobiologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('referred_microbiology');
		$rows = $this->getReferralTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['typhoid_fever'] = 0;
		$test_type_counts['cholera'] = 0;
		$test_type_counts['dysentry'] = 0;
		$test_type_counts['rota_virus'] = 0;
		$test_type_counts['meningitis'] = 0;
		$test_type_counts['neonatal_tetanus'] = 0;
		$test_type_counts['plague'] = 0;
		$test_type_counts['isolates'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['typhoid_fever']){
	 			$test_type_counts['typhoid_fever'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['cholera']){
	 			$test_type_counts['cholera'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['dysentry']){
	 			$test_type_counts['dysentry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['rota_virus']){
	 			$test_type_counts['rota_virus'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['meningitis']){
	 			$test_type_counts['meningitis'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['neonatal_tetanus']){
	 			$test_type_counts['neonatal_tetanus'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['plague']){
	 			$test_type_counts['plague'] = $row->total;
	 		}else{
	 			$test_type_counts['isolates'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getReferredVirologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('referred_virology');
		$rows = $this->getReferralTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['measles'] = 0;
		$test_type_counts['vhf'] = 0;
		$test_type_counts['animal_bites'] = 0;
		$test_type_counts['suspected_outbreak_sample'] = 0;
		$test_type_counts['hepbAg'] = 0;
		$test_type_counts['hepb_vl'] = 0;
		$test_type_counts['hepc_vl'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['measles']){
	 			$test_type_counts['measles'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['vhf']){
	 			$test_type_counts['vhf'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['animal_bites']){
	 			$test_type_counts['animal_bites'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['suspected_outbreak_sample']){
	 			$test_type_counts['suspected_outbreak_sample'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hepbAg']){
	 			$test_type_counts['hepbAg'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hepb_vl']){
	 			$test_type_counts['hepb_vl'] = $row->total;
	 		}else{
	 			$test_type_counts['hepc_vl'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getReferredParasitologyCounts($month){
		$test_type_ids = $this->getTestTypeIDs('referred_parasitology');
		$rows = $this->getReferralTestCountsByLabSection($test_type_ids['test_category_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['hemo_parasites'] = 0;
		$test_type_counts['intestinal_parasites'] = 0;
		$test_type_counts['tissue_parasites'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['hemo_parasites']){
	 			$test_type_counts['hemo_parasites'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['intestinal_parasites']){
	 			$test_type_counts['intestinal_parasites'] = $row->total;
	 		}else{
	 			$test_type_counts['tissue_parasites'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getEquipmentBreakdownCounts($month){
		$test_type_ids = $this->getTestTypeIDs('equipmentBreakdown');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getReagentStockoutCounts($month){
		$test_type_ids = $this->getTestTypeIDs('reagent_stockout');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getSuppliesStockoutCounts($month){
		$test_type_ids = $this->getTestTypeIDs('supplies_stockout');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getPowerOutageCounts($month){
		$test_type_ids = $this->getTestTypeIDs('power_outage');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getTestingExpertiseCounts($month){
		$test_type_ids = $this->getTestTypeIDs('no_testing_expertise');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getRequiredEquipmentCounts($month){
		$test_type_ids = $this->getTestTypeIDs('required_equipment');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getConfirmatoryTestingCounts($month){
		$test_type_ids = $this->getTestTypeIDs('confirmatory_testing');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getQaRetestingCounts($month){
		$test_type_ids = $this->getTestTypeIDs('qa_retesting');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getOtherReferralReasonsCounts($month){
		$test_type_ids = $this->getTestTypeIDs('other_referral_reasons');
		$rows = $this->getReferralTestCountsByReasons($test_type_ids['referral_reason'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['CD4'] = 0;
		$test_type_counts['TB'] = 0;
		$test_type_counts['CBC'] = 0;
		$test_type_counts['Chemistry'] = 0;
		$test_type_counts['Microbiology'] = 0;
		$test_type_counts['hiv'] = 0;
		$test_type_counts['VDRL'] = 0;
		$test_type_counts['Haematology'] = 0;
		$test_type_counts['Parasitolog'] = 0;
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->test_type_id == $test_type_ids['CD4']){
	 			$test_type_counts['CD4'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['TB']){
	 			$test_type_counts['TB'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['CBC']){
	 			$test_type_counts['CBC'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Chemistry']){
	 			$test_type_counts['Chemistry'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Microbiology']){
	 			$test_type_counts['Microbiology'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['hiv']){
	 			$test_type_counts['hiv'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['VDRL']){
	 			$test_type_counts['VDRL'] = $row->total;
	 		}else if((int)$row->test_type_id == $test_type_ids['Haematology']){
	 			$test_type_counts['Haematology'] = $row->total;
	 		}else{
	 			$test_type_counts['Parasitolog'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getKlebsiellaOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('klebsiella_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getEscherichiaOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('escherichia_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getsalmonellaOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('salmonella_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getShigellaOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('shigella_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getNeisseriaOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('neisseria_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getStaphylococcusOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('staphylococcus_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getStreptococcusOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('streptococcus_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getAcinetobacterOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('acinetobacter_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getVibrioOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('vibrio_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getEnterococcusOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('enterococcus_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getHaemophilusOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('haemophilus_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getNeisseriamOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('neisseriam_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getCampylobacterOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('campylobacter_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getOthersOrganismCounts($month){
		$test_type_ids = $this->getTestTypeIDs('others_organism');
		$rows = $this->getAMRservillence($test_type_ids['organism_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['ampicilin'] = 0;
		$test_type_counts['azithromycin'] = 0;
		$test_type_counts['amikacin'] = 0;
		$test_type_counts['ceftriaxone'] = 0;
		$test_type_counts['ceftazidime'] = 0;
		$test_type_counts['cefotaxime'] = 0;
		$test_type_counts['cefoxitin'] = 0;
		$test_type_counts['cefixime'] = 0;
		$test_type_counts['cotrimoxazole'] = 0;
		$test_type_counts['ciprofloxacin'] = 0;
		$test_type_counts['colistin'] = 0;
		$test_type_counts['gentamicin'] = 0;
		$test_type_counts['imipenem'] = 0;
		$test_type_counts['levofloxacin'] = 0;
		$test_type_counts['meropenem'] = 0;
		$test_type_counts['oxacillin'] = 0;
		$test_type_counts['penicillin_g'] = 0;
		$test_type_counts['vancomycin'] = 0;
		$test_type_counts['augmentin'] = 0;
		$test_type_counts['chloramphenicol'] = 0;
		$test_type_counts['clindamycin'] = 0;
		$test_type_counts['erythromycin'] = 0;
		$test_type_counts['nalidixic_acid'] = 0;
		$test_type_counts['nitrofurantoin'] = 0;
		$test_type_counts['piperacillin'] = 0;
		$test_type_counts['piperacillin_tazobactam'] = 0;
		$test_type_counts['tetracycline'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->drug_id == $test_type_ids['ampicilin']){
	 			$test_type_counts['ampicilin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['azithromycin']){
	 			$test_type_counts['azithromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['amikacin']){
	 			$test_type_counts['amikacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftriaxone']){
	 			$test_type_counts['ceftriaxone'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ceftazidime']){
	 			$test_type_counts['ceftazidime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefotaxime']){
	 			$test_type_counts['cefotaxime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cotrimoxazole']){
	 			$test_type_counts['cotrimoxazole'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['ciprofloxacin']){
	 			$test_type_counts['ciprofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['colistin']){
	 			$test_type_counts['colistin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefixime']){
	 			$test_type_counts['cefixime'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['cefoxitin']){
	 			$test_type_counts['cefoxitin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['gentamicin']){
	 			$test_type_counts['gentamicin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['imipenem']){
	 			$test_type_counts['imipenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['levofloxacin']){
	 			$test_type_counts['levofloxacin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['meropenem']){
	 			$test_type_counts['meropenem'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['oxacillin']){
	 			$test_type_counts['oxacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['penicillin_g']){
	 			$test_type_counts['penicillin_g'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['vancomycin']){
	 			$test_type_counts['vancomycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['augmentin']){
	 			$test_type_counts['augmentin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['chloramphenicol']){
	 			$test_type_counts['chloramphenicol'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['clindamycin']){
	 			$test_type_counts['clindamycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['erythromycin']){
	 			$test_type_counts['erythromycin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nalidixic_acid']){
	 			$test_type_counts['nalidixic_acid'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['nitrofurantoin']){
	 			$test_type_counts['nitrofurantoin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin']){
	 			$test_type_counts['piperacillin'] = $row->total;
	 		}else if((int)$row->drug_id == $test_type_ids['piperacillin_tazobactam']){
	 			$test_type_counts['piperacillin_tazobactam'] = $row->total;
	 		}else{
	 			$test_type_counts['tetracycline'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getBloodSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('blood_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] =$row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getStoolSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('stool_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getUrineSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('urine_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//dd($rows);//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		//dd($rows);
	 	foreach($rows as $row){
	 		//echo $test_type_ids['hemolyzed_specimen']

	 		if($row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}elseif($row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}elseif((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getSputumSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('sputum_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getPusSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('pus_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $test_type_counts['hemolyzed_specimen'] + 1;
	 		}else if((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getGenitalSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('genital_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getSkinSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('skin_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}

	private function getOtherSpecimenRejectionCounts($month){
		$test_type_ids = $this->getTestTypeIDs('other_specimen_rejection');
		$rows = $this->getSpecimenRejectionTotalBySampleType($test_type_ids['specimen_type_id'],$month);
		//$test_type_counts = $this->getTestTypeInitialCounts('hematology');
		$test_type_counts['inadequate_specimen_volume'] = 0;
		$test_type_counts['hemolyzed_specimen'] = 0;
		$test_type_counts['specimen_without_lab_request_form'] = 0;
		$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = 0;
		$test_type_counts['Specimen_without_label_or_identifier'] = 0;
		$test_type_counts['Wrong_specimen_label'] = 0;
		$test_type_counts['Unclear_specimen_label'] = 0;
		$test_type_counts['Wrong_specimen_container'] = 0;
		$test_type_counts['Damaged_specimen_container'] = 0;
		$test_type_counts['Too_old_specimen'] = 0;
		$test_type_counts['Date_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Time_of_specimen_collection_not_specified'] = 0;
		$test_type_counts['Specimen_type_unacceptable_for_required_test'] = 0;
		$test_type_counts['Other_reasons'] = 0;
		
	 	foreach($rows as $row){
	 		//dd($row);
	 		if((int)$row->reason_id == $test_type_ids['inadequate_specimen_volume']){
	 			$test_type_counts['inadequate_specimen_volume'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['hemolyzed_specimen']){
	 			$test_type_counts['hemolyzed_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['specimen_without_lab_request_form']){
	 			$test_type_counts['specimen_without_lab_request_form'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['No_test_specified_on_lab_request_form_accompanying_specimen']){
	 			$test_type_counts['No_test_specified_on_lab_request_form_accompanying_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_without_label_or_identifier']){
	 			$test_type_counts['Specimen_without_label_or_identifier'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_label']){
	 			$test_type_counts['Wrong_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Damaged_specimen_container']){
	 			$test_type_counts['Damaged_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Too_old_specimen']){
	 			$test_type_counts['Too_old_specimen'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Date_of_specimen_collection_not_specified']){
	 			$test_type_counts['Date_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Wrong_specimen_container']){
	 			$test_type_counts['Wrong_specimen_container'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Unclear_specimen_label']){
	 			$test_type_counts['Unclear_specimen_label'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Time_of_specimen_collection_not_specified']){
	 			$test_type_counts['Time_of_specimen_collection_not_specified'] = $row->total;
	 		}else if((int)$row->reason_id == $test_type_ids['Specimen_type_unacceptable_for_required_test']){
	 			$test_type_counts['Specimen_type_unacceptable_for_required_test'] = $row->total;
	 		}else{
	 			$test_type_counts['Other_reasons'] = $row->total;
	 		}

	 	}
	 	return $test_type_counts;
	}


	private function getTestTypeIDs($lab_section){
		$test_type_ids = [
						'isolate'=>
							[
							'organism' => 0,
							'Klebsiella_pneumoniae' => 72,
							'Escherichia_coli' => 2,
							'Salmonella_spp' => 16,
							'Shigella_spp' => 13,
							'Neisseria_gonorrhoeae' => 42,
							'Staphylococcus_aureus' => 26,
							// 'shigella_dysentery' => 0,
							'Streptococcus_pneumoniae' => 61,
							'Acinetobacter_baumannii' => 13,
							'Vibrio_cholerae' => 20,
							'Enterococcus_spp' => 34,
							'Haemophilus_influenzae' => 52,
							'Neisseria_meningitides' => 43,
							'Campylobacter' => 0,
							'others' => 0,
						],
						'hematology'=>
							[
							'test_category_id' => 3, //the id of the hematology - check test_categories table
							'hb_non_automated' => 4,
							'vdrl_rrr' => 12,
							'cbc' => 22,
							'film_comment' => 59,
							'tpha' => 36,
							'esr' =>67, 
							'shigella_dysentery' => 105,
							'bleeding_time' => 100,
							'Hepatitisb_sags' => 110,
							'prothrombin_time' => 115,
							'brucella' => 14,
							'clotting_time' => 120,
							'pregnancy_test' => 42,
							'sickle_cell' => 10,
						],
						'serology' => [
							'test_category_id' => 4, //the id of the serology - check test_categories table
							'vdrl_rrr' => 12,
							'tpha' => 36,
							'shigella_dysentery' => 104,
							'hepatitisb_sags' => 106,
							'Hepatitisb_sags' => 106,
							'brucella' => 14,
							'pregnancy_test' => 42,
							'crag' => 108,
							'rheumatoid_factor' => 110,
							'hepb_core_ag' => 30,
							'hepa' => 114,
							'hepc' => 116,
						],
						'blood_transfusion' => [
							'test_category_id' => 5, //the id of the serology - check test_categories table
							'ahb_combs_test' => 8,
							'abo_grouping' => 50,
							'rhesus_grouping' => 'N/A',
							'cross_matching' => 51,
						],
						//test based analysis
						'culture_and_sensitivity_specimen' => [
							'test_type_id' => 5, //the id of the cul n sens test - check test_types table
							'blood' => 23,
							'urine' => 20,
							'stool' => 16,
							'sputum' => 24,
							'nosal_swab' => 6,
							'rectal_swab' => 11,
							'wound_swab' => 15,
							'pus_swab' => 10,
							'eye_swab' => 27,
							'ear_swab' => 27,
							'throat_swab' => 18,
							'uretheral_swab' => 27,
						],
						'microbiology' => [
							'test_category_id' => 2, //the id of the serology - check test_categories table
							'test_type_id' => 5, //the id of the microbiology test - check test_types table
							'auramine_fm' => 20,
							'zn_for_afb' => 20,
							'leishman_stain' => 26,
							'gram' => 13,
							'india_ink' => 24,
							'urine_microscopy' => 3,
							'wet_prep' => 5,
							'others' => 15,
							
						],
						'parasitology' => [
							'test_category_id' => 1, //the id of the serology - check test_categories table
							'test_type_id' => 5, //the id of the parasitology test - check test_types table
							'malaria_microscopy' => 1,
							'malaria_rdts' => 34,
							'trypasonoma' => 13,
							'micro_filaria' => 24,
							'leishmania' => 3,
							'trichinella' => 5,
							'borrellia' => 15,
						],
						'stoolmicroscopy' => [
							'test_category_id' => 5, //the id of the serology - check test_categories table
							'test_type_id' => 5, //the id of the stool test - check test_types table
							'entamoeba' => 22,
							'giardia' => 26,
							'cryptosporidium' => 13,
							'isospora' => 24,
							'cyclospora' => 3,
							'strongyloides' => 5,
							'shistosoma' => 15,
							'taenia' => 16,
							'askaris' => 18,
							'hookworm' => 19,
							'trichuris' => 20,
							'other_parasites' => 25,

						],
						'immunology' => [
							'cd4' => 47, 
							'hiv_viral_load' => 53,
							'hepb' => 30,
						],
						'molecular' => [
							'tb_genexpert' => 48, 
							'latent_tb' => 501,
							'tb_lam' => 49,
						],
						'chemistry' => [//get ids from measures table
							'test_category_id' => 6, //the id of the serology - check test_categories table
							'urea' => 510, 
							'calcium' => 92,
							'potassium' => 511,
							'albumin' => 50,
							'total_protein' => 55,
							'sodium' => 512,
							'creatinine' => 513,
							'alt' => 514,
							'ast' => 515,
							'protein' => 12,
							'triglycerides' => 517,
							'cholesterol' => 518,
							'free_t3' => 519,
							'free_t4' => 520,
							'tsh' => 521,
							'alkaline_phosphate' => 516,
							'amylase' => 91,
							'glucose' => 91,
							'total_bilirubin' => 91,
							'lipase' => 91,
							'afp' => 91,

						],
						'referralTests' => [//get ids from measures table
							'test_category_id' => 5, //the id of the serology - check test_categories table
							'cd4' => 510, 
							'sickle_cell_confirmation' => 92,
							'histology' => 511,
							'polio' => 512,
							'sars' => 513,
							'tb_genexpert' => 514,
							'mdr_tb' => 515,
			
						],
						'referred_microbiology' => [//get ids from measures table
							'test_category_id' => 2, //the id of the serology - check test_categories table
							'typhoid_fever' => 510, 
							'cholera' => 92,
							'dysentry' => 511,
							'rota_virus' => 512,
							'meningitis' => 513,
							'neonatal_tetanus' => 514,
							'plague' => 515,
							'isolates' => 12,
							
						],
						'referred_parasitology' => [//get ids from measures table
							'status' => 1, //the id of the serology - check test_categories table
							'test_category_id' => 1,
							'hemo_parasites' => 510, 
							'intestinal_parasites' => 92,
							'tissue_parasites' => 511,

						],
						'referred_virology' => [//get ids from measures table
							'test_category_id' => 10, //the id of the serology - check test_categories table
							'measles' => 510, 
							'vhf' => 510, 
							'animal_bites' => 92,
							'suspected_outbreak_sample' => 511,
							'hepbAg' => 512,
							'hepb_vl' => 513,
						],
						'equipmentBreakdown' => [
							'referral_reason' => 1,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'reagent_stockout' => [
							'referral_reason' => 2,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'supplies_stockout' => [
							'referral_reason' => 3,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'power_outage' => [
							'referral_reason' => 4,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'no_testing_expertise' => [
							'referral_reason' => 5,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'required_equipment' => [
							'referral_reason' => 1,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'confirmatory_testing' => [
							'referral_reason' => 1,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'qa_retesting' => [
							'referral_reason' => 1,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'other_referral_reasons' => [
							'referral_reason' => 1,
							'CD4' => 28,
							'TB' => 41,
							'CBC' => 30,
							'Chemistry' => 20,
							'Microbiology' => 12,
							'hiv' => 29,
							'VDRL' => 12,
							'Haematology' => 16,
							'Parasitolog' => 18,	
						],
						'referred_parasitology' => [//get ids from measures table
							'test_category_id' => 5, //the id of the serology - check test_categories table
							'hemo_parasites' => 510, 
							'intestinal_parasites' => 92,
							'tissue_parasites' => 511,
						 ],
						'klebsiella_organism' => [//get ids from measures table
							'organism_id' => 72, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'escherichia_organism' => [//get ids from measures table
							'organism_id' => 2, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'salmonella_organism' => [//get ids from measures table
							'organism_id' => 16, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'shigella_organism' => [//get ids from measures table
							'organism_id' => 13, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'neisseria_organism' => [//get ids from measures table
							'organism_id' => 42, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'staphylococcus_organism' => [//get ids from measures table
							'organism_id' => 23, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'streptococcus_organism' => [//get ids from measures table
							'organism_id' => 61, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'acinetobacter_organism' => [//get ids from measures table
							'organism_id' => 13, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'vibrio_organism' => [//get ids from measures table
							'organism_id' => 20, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'enterococcus_organism' => [//get ids from measures table
							'organism_id' => 34, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'haemophilus_organism' => [//get ids from measures table
							'organism_id' => 52, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'neisseriam_organism' => [//get ids from measures table
							'organism_id' => 43, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'campylobacter_organism' => [//get ids from measures table
							'organism_id' => 30, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,

						],
						'others_organism' => [//get ids from measures table
							'organism_id' => 1, //the id of the serology - check test_categories table
							'ampicilin' => 2,
							'azithromycin' => 2,
							'amikacin' => 1,
							'ceftriaxone' => 6,
							'ceftazidime' => 5,
							'cefotaxime' => 4,
							'cefoxitin' => 15,
							'cefixime' => 34,
							'cotrimoxazole' => 12,
							'ciprofloxacin' => 11,
							'colistin' => 23,
							'gentamicin' => 13,
							'imipenem' => 14,
							'levofloxacin' => 21,
							'meropenem' => 15,
							'oxacillin' => 36,
							'penicillin_g' => 29,
							'vancomycin' => 27,
							'augmentin' => 3,
							'chloramphenicol' => 10,
							'clindamycin' => 26,
							'erythromycin' => 25,
							'nalidixic_acid' => 16,
							'nitrofurantoin' => 19,
							'piperacillin' => 18,
							'piperacillin_tazobactam' => 17,
							'tetracycline' => 24,
						],
						'blood_specimen_rejection' => [
							'specimen_type_id' => 23,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
						],
						'stool_specimen_rejection' => [
							'specimen_type_id' => 13,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
							],
						'urine_specimen_rejection' => [
							'specimen_type_id' => 13,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
							],
						'sputum_specimen_rejection' => [
							'specimen_type_id' => 24,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
							],
						'pus_specimen_rejection' => [
							'specimen_type_id' => 10,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
							],
						'genital_specimen_rejection' => [
							'specimen_type_id' => 21,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
							],
						'skin_specimen_rejection' => [
							'specimen_type_id' => 14,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
							],
						'other_specimen_rejection' => [
							'specimen_type_id' => 19,
							'inadequate_specimen_volume' => 1,
							'hemolyzed_specimen' => 2,
							'specimen_without_lab_request_form' => 3,
							'No_test_specified_on_lab_request_form_accompanying_specimen' => 4,
							'Specimen_without_label_or_identifier' => 5,
							'Wrong_specimen_label' => 38,
							'Unclear_specimen_label' => 7,
							'Wrong_specimen_container' => 8,
							'Damaged_specimen_container' => 11,
							'Too_old_specimen' => 16,
							'Date_of_specimen_collection_not_specified' => 13,
							'Time_of_specimen_collection_not_specified' => 14,
							'Specimen_type_unacceptable_for_required_test' => 15,
							'Other_reasons' => 19,
						]
					];
		return $test_type_ids[$lab_section];
	}

	private function getTestTypeInitialCounts($lab_section){
		//blood transfusion
		$test_types['blood_transfusion']['ahb_combs_test'] = 0;
		$test_types['blood_transfusion']['abo_grouping'] = 0;
		$test_types['blood_transfusion']['rhesus_grouping'] = 'N/A';
		$test_types['blood_transfusion']['cross_matching'] = 0;
		//test based analysis - culture and sensitivity
		$test_types['culture_and_sensitivity_specimen']['urine'] = 0;
		$test_types['culture_and_sensitivity_specimen']['blood'] = 0;
		$test_types['culture_and_sensitivity_specimen']['stool'] = 0;
		$test_types['culture_and_sensitivity_specimen']['swabs'] = 0;
		$test_types['culture_and_sensitivity_specimen']['sputum'] = 0;
		//immunology
		$test_types['immunology']['cd4'] = 0;
		$test_types['immunology']['hiv_viral_load'] = 0;
		$test_types['immunology']['hepb'] = 0;
		//molecular
		$test_types['molecular']['tb_genexpert'] = 0;
		$test_types['molecular']['latent_tb'] = 0;
		$test_types['molecular']['tb_lam'] = 0;
		return $test_types[$lab_section]; 
	}

	private function getHivTestByPurpose($month){
		$ret_array =  array();
		$d_hct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('measure_id','=','1')->where('purpose','=','hct')
		->where('result', '!=', '')
		->where('unhls_tests.time_verified', 'LIKE', $month)->get();
		$ret_array['determine']['hct']= $d_hct[0]->counter;
		
		$d_emct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','emtct')->where('result', '!=', '')->get();
		$ret_array['determine']['emct']= $d_emct[0]->counter;

		$d_clinic = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','clinical_diagnosis')->where('result', '!=', '')->get();
		$ret_array['determine']['clinic']= $d_clinic[0]->counter;

		$d_smc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','smc')->where('result', '!=', '')->get();
		$ret_array['determine']['smc']= $d_smc[0]->counter;

		$d_repeat = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','repeat_test')->where('result', '!=', '')->get();
		$ret_array['determine']['repeat']= $d_repeat[0]->counter;

		$d_verification = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','test_for_verification')->where('result', '!=', '')->get();
		$ret_array['determine']['verification']= $d_verification[0]->counter;

		$d_inconclusive = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','inconclusive_results')->where('result', '!=', '')->get();
		$ret_array['determine']['inconclusive']= $d_inconclusive[0]->counter;

		$d_dna = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','dna_confirmatory_test')->where('result', '!=', '')->get();
		$ret_array['determine']['dna']= $d_dna[0]->counter;

		$d_iqc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','iqc')->where('result', '!=', '')->get();
		$ret_array['determine']['iqc']= $d_iqc[0]->counter;

		$d_eqa = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','1')->where('purpose','=','eqa')->where('result', '!=', '')->get();
		$ret_array['determine']['eqa']= $d_eqa[0]->counter;

		// Statpak counts
		$s_hct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','hct')->where('result', '!=', '')->get();
		$ret_array['statpak']['hct']= $d_hct[0]->counter;

		$s_emct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','emtct')->where('result', '!=', '')->get();
		$ret_array['statpak']['emct']= $d_emct[0]->counter;

		$s_clinic = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','clinical_diagnosis')->where('result', '!=', '')->get();
		$ret_array['statpak']['clinic']= $d_clinic[0]->counter;

		$s_smc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','smc')->where('result', '!=', '')->get();
		$ret_array['statpak']['smc']= $d_smc[0]->counter;

		$s_repeat = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','repeat_test')->where('result', '!=', '')->get();
		$ret_array['statpak']['repeat']= $d_repeat[0]->counter;

		$s_verification = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','test_for_verification')->where('result', '!=', '')->get();
		$ret_array['statpak']['verification']= $d_verification[0]->counter;

		$s_inconclusive = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','inconclusive_results')->where('result', '!=', '')->get();
		$ret_array['statpak']['inconclusive']= $s_inconclusive[0]->counter;

		$s_dna = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','dna_confirmatory_test')->where('result', '!=', '')->get();
		$ret_array['statpak']['dna']= $s_dna[0]->counter;

		$s_iqc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','iqc')->where('result', '!=', '')->get();
		$ret_array['statpak']['iqc']= $s_iqc[0]->counter;

		$s_eqa = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','2')->where('purpose','=','eqa')->where('result', '!=', '')->get();
		$ret_array['statpak']['eqa']= $s_eqa[0]->counter;

		// SD-Bioline counts
		$sd_hct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','hct')->where('result', '!=', '')	->get();
		$ret_array['sdbioline']['hct']= $sd_hct[0]->counter;

		$sd_emct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','emtct')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['emct']= $sd_emct[0]->counter;

		$sd_clinic = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','clinical_diagnosis')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['clinic']= $sd_clinic[0]->counter;

		$sd_smc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','smc')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['smc']= $sd_smc[0]->counter;

		$sd_repeat = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','repeat_test')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['repeat']= $sd_repeat[0]->counter;

		$sd_verification = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','test_for_verification')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['verification']= $sd_verification[0]->counter;

		$sd_inconclusive = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','inconclusive_results')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['inconclusive']= $sd_inconclusive[0]->counter;

		$sd_dna = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','dna_confirmatory_test')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['dna']= $sd_dna[0]->counter;

		$sd_iqc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','iqc')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['iqc']= $sd_iqc[0]->counter;

		$sd_eqa = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','3')->where('purpose','=','eqa')->where('result', '!=', '')->get();
		$ret_array['sdbioline']['eqa']= $sd_eqa[0]->counter;

		// HIV-Syphilis Duo count
		$h_hct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','hct')->where('result', '!=', '')	->get();
		$ret_array['syphilis']['hct']= $h_hct[0]->counter;

		$h_emct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','emtct')->where('result', '!=', '')->get();
		$ret_array['syphilis']['emct']= $h_emct[0]->counter;

		$h_clinic = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','clinical_diagnosis')->where('result', '!=', '')->get();
		$ret_array['syphilis']['clinic']= $h_clinic[0]->counter;

		$h_smc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','smc')->where('result', '!=', '')->get();
		$ret_array['syphilis']['smc']= $h_smc[0]->counter;

		$h_repeat = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','repeat_test')->where('result', '!=', '')->get();
		$ret_array['syphilis']['repeat']= $h_repeat[0]->counter;

		$h_verification = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','test_for_verification')->where('result', '!=', '')->get();
		$ret_array['syphilis']['verification']= $h_verification[0]->counter;

		$h_inconclusive = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','inconclusive_results')->where('result', '!=', '')->get();
		$ret_array['syphilis']['inconclusive']= $h_inconclusive[0]->counter;

		$h_dna = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','dna_confirmatory_test')->where('result', '!=', '')->get();
		$ret_array['syphilis']['dna']= $h_dna[0]->counter;

		$h_iqc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','iqc')->where('result', '!=', '')->get();
		$ret_array['syphilis']['iqc']= $h_iqc[0]->counter;

		$h_eqa = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','100')->where('purpose','=','eqa')->where('result', '!=', '')->get();
		$ret_array['syphilis']['eqa']= $h_eqa[0]->counter;

		// Oraquick count
		$o_hct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','hct')->where('result', '!=', '')	->get();
		$ret_array['oraquick']['hct']= $o_hct[0]->counter;

		$o_emct = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','emtct')->where('result', '!=', '')->get();
		$ret_array['oraquick']['emct']= $o_emct[0]->counter;

		$o_clinic = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','clinical_diagnosis')->where('result', '!=', '')->get();
		$ret_array['oraquick']['clinic']= $o_clinic[0]->counter;

		$o_smc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','smc')->where('result', '!=', '')->get();
		$ret_array['oraquick']['smc']= $o_smc[0]->counter;

		$o_repeat = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','repeat_test')->where('result', '!=', '')->get();
		$ret_array['oraquick']['repeat']= $o_repeat[0]->counter;

		$o_verification = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','test_for_verification')->where('result', '!=', '')->get();
		$ret_array['oraquick']['verification']= $o_verification[0]->counter;

		$o_inconclusive = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','inconclusive_results')->where('result', '!=', '')->get();
		$ret_array['oraquick']['inconclusive']= $o_inconclusive[0]->counter;

		$o_dna = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','dna_confirmatory_test')->where('result', '!=', '')->get();
		$ret_array['oraquick']['dna']= $o_dna[0]->counter;

		$o_iqc = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('unhls_tests.time_verified', 'LIKE', $month)
		->where('measure_id','=','101')->where('purpose','=','iqc')->where('result', '!=', '')->get();
		$ret_array['oraquick']['iqc']= $o_iqc[0]->counter;

		$o_eqa = DB::table("unhls_test_results")
		->select("unhls_tests.purpose","measures.name", DB::raw("COUNT(unhls_tests.id) as counter"))
		->join("measures","measures.id","=","unhls_test_results.measure_id")
		->join("unhls_tests","unhls_test_results.test_id","=","unhls_tests.id")
		->where('measure_id','=','101')->where('purpose','=','eqa')->where('result', '!=', '')->get();
		$ret_array['oraquick']['eqa']= $o_eqa[0]->counter;

//get the totals now
		$ret_array['determine']['total'] = $ret_array['determine']['hct']+$ret_array['determine']['emct']+$ret_array['determine']['clinic']+$ret_array['determine']['smc']+$ret_array['determine']['repeat']+$ret_array['determine']['verification']+
$ret_array['determine']['inconclusive']+$ret_array['determine']['dna']+$ret_array['determine']['iqc']+$ret_array['determine']['eqa'];

$ret_array['statpak']['total'] = $ret_array['statpak']['hct']+$ret_array['statpak']['emct']+$ret_array['statpak']['clinic']+$ret_array['statpak']['smc']+$ret_array['statpak']['repeat']+$ret_array['statpak']['verification']+
$ret_array['statpak']['inconclusive']+$ret_array['statpak']['dna']+$ret_array['statpak']['iqc']+$ret_array['statpak']['eqa'];

$ret_array['sdbioline']['total'] = $ret_array['sdbioline']['hct']+$ret_array['sdbioline']['emct']+$ret_array['sdbioline']['clinic']+$ret_array['sdbioline']['smc']+$ret_array['sdbioline']['repeat']+$ret_array['sdbioline']['verification']+
$ret_array['sdbioline']['inconclusive']+$ret_array['sdbioline']['dna']+$ret_array['sdbioline']['iqc']+$ret_array['sdbioline']['eqa'];

$ret_array['syphilis']['total'] = $ret_array['syphilis']['hct']+$ret_array['syphilis']['emct']+$ret_array['syphilis']['clinic']+$ret_array['syphilis']['smc']+$ret_array['syphilis']['repeat']+$ret_array['syphilis']['verification']+
$ret_array['syphilis']['inconclusive']+$ret_array['syphilis']['dna']+$ret_array['syphilis']['iqc']+$ret_array['syphilis']['eqa'];

$ret_array['oraquick']['total'] = $ret_array['oraquick']['hct']+$ret_array['oraquick']['emct']+$ret_array['oraquick']['clinic']+$ret_array['oraquick']['smc']+$ret_array['oraquick']['repeat']+$ret_array['oraquick']['verification']+
$ret_array['oraquick']['inconclusive']+$ret_array['oraquick']['dna']+$ret_array['oraquick']['iqc']+$ret_array['oraquick']['eqa'];
		

		return $ret_array;
	}
/*SELECT ur.id, ur.test_id, mr.measure_id, mr.interpretation  
FROM unhls_test_results ur
INNER JOIN measure_ranges mr ON(ur.measure_id = mr.measure_id)*/

}
