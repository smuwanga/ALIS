<?php

class UNHLSStaff extends Eloquent
{
	protected $table = "unhls_staff";
}