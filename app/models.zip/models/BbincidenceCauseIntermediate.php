<?php

use Illuminate\Database\Eloquent\SoftDeletingTrait;

class BbincidenceCauseIntermediate extends Eloquent
{
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'unhls_bbincidences_cause';
	

}