<?php


class ExternalUser extends Eloquent {

	protected $table = "external_users";

}