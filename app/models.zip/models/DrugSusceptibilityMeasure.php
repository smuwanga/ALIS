<?php

class DrugSusceptibilityMeasure extends Eloquent
{

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	// todo: change name of this from Drug susceptibility measures to drug susceptibility measures
	protected $table = 'drug_susceptibility_measures';
	public $timestamps = false;
}
