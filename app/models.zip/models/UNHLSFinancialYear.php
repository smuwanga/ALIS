<?php

class UNHLSFinancialYear extends Eloquent
{
	protected $table = "unhls_financial_years";
}