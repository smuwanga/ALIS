<?php

class DailyHIVCount extends Eloquent
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'daily_hiv_counts';

    public $timestamps = false;
}
