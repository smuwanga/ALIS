@section('loginFooter')
	<table align='center' width="70%" style="font-size:12px;" border='0'>
		<thead>
			<tr>
				<td colspan="3" valign="bottom" valign="bottom"><font color="black"><i>Check out other laboratory services information systems</i></font></td>
			</tr>
			<tr>
				<td><a href="https://edash.cphluganda.org/" target="_blank">EID Dashboard</a></td>
				<td><a href="https://vldash.cphluganda.org/" target="_blank">VL Dashboard</a></td>
				<td><a href="#">Help/FAQs</a></td>
				<td><a href="#">Sample & Results Tracking</a></td>
				<td><a href="#">Lab Regulatory Documents</a></td>
				<td><a href="#">Lab services evaluation</a></td>
				<td><a href="http://www.cphl.go.ug/" target="_blank">CPHL Website</a></td>
			</tr>
		</thead>	
	</table>
@show