<?php

class UNHLSEquipmentInventory extends Eloquent
{
	protected $table = "unhls_equipment_inventory";
}