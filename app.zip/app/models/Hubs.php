<?php

class Hubs extends \Eloquent {
	protected $table = "hubs";
}
