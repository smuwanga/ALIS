<?php

class UNHLSWarehouse extends Eloquent
{
	protected $table = "unhls_warehouse";
}