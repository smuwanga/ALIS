<?php

class UNHLSEquipmentSupplier extends Eloquent
{
	protected $table = "unhls_equipment_suppliers";
}