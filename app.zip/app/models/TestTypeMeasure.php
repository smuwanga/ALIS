<?php

class TestTypeMeasure extends Eloquent
{
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'testtype_measures';

	public $timestamps = false;
}