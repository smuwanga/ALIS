<?php

class SpecimenStatus extends Eloquent
{
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'specimen_statuses';

	public $timestamps = false;
}