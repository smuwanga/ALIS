<?php

class WardType extends \Eloquent {
	

	/**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'ward_type';
    protected $fillable = [];

    public $timestamps = false;
}