<?php

class FinancialYear extends Eloquent
{

	protected $table = 'unhls_financial_years';
	public $timestamps = true;

}