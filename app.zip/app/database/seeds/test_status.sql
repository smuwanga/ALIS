INSERT INTO test_statuses(id, name, test_phase_id) VALUES 
(7, 'approved', 3);
INSERT INTO `unhls_financial_years` (`id`, `year`, `created_at`, `updated_at`) VALUES (NULL, '2020/2021', '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000');