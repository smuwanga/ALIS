INSERT INTO `permissions` (`id`,`name`, `display_name`, `created_at`, `updated_at`) VALUES 
(28,'approve_test_results', 'Can approve test results as the last phase', '2019-01-14 09:46:00', '2019-01-14 09:46:00'),
(29,'cancel_test', 'Can cancel a test', '2019-01-14 09:46:00', '2019-01-14 09:46:00'),
(30,'recall_report', 'Can recall a report of a Patient', '2019-01-14 09:46:00', '2019-01-14 09:46:00');