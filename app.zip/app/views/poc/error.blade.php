@extends("layout")
@section("content")
<div class="content error-page text-danger">
            <h2><i>Oops!</i> Sample ID already exists. Please assign the patient a new Sample ID.</h2>
            <div>
                <a class="btn btn-default" href="poc/create">Return to previous page</a>
            </div>
</div>