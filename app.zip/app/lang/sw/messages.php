<?php

return array(
    /* 
    | Generic names
    */
	'cancel' => 'Ghairi',
   	'create' => 'Unda',
    'delete' => 'Futa',
    'description' => 'Ufafanuzi',
    'edit' => 'Hariri',
    'home' => 'Nyumbani',
    'login' => 'Ingia',
    'name' => 'Jina',
    'password' => 'Nywila',
    'save' => 'Hifadhi',
    'username' => 'Akaunti',
    'view' => 'Tazama',
    /* 
    | Generic phrases
    */
    'confirm-delete-title' => 'Thibitisha Ufutaji',
    'confirm-delete-message' => 'Unahakika wataka kufuta?',
    'confirm-delete-irreversible' => 'Kitendo hiki hakiwezi kubatilishwa.',
    /* 
    |Test Categories
    */
    'create-test-category' => 'Unda Kitengo cha Maabara',
    'edit-test-category' => 'Hariri Kitengo cha Maabara',
    'list-test-categories' => 'Orodhesha Vitengo vya Maabara',
    'success-creating-test-category' => 'Kitengo kipya cha maabara kimeundwa.',
    'success-deleting-test-category' => 'Kitengo cha maabara ondolewa.',
    'success-updating-test-category' => 'Kitengo hiki kimehifadhiwa!',
    'test-category' => 'Kitengo cha Maabara',
    'test-category-details' => 'Viungo vya Kitengo cha Maabara',
);